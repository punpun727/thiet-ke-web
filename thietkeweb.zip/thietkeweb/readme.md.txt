# 🛋️ Furniro - Website Bán Hàng Nội Thất

## 📌 Giới thiệu
**Furniro** là một website bán hàng nội thất cơ bản được xây dựng bằng **HTML, CSS, JavaScript và Bootstrap 5**.  
Website có giao diện hiện đại, bố cục chuẩn e-commerce với đầy đủ các thành phần: **Navbar, Breadcrumb, Shop page, Filter, Sort, Footer, Newsletter**.  

## 🚀 Chức năng chính
- **Trang Shop**:
  - Hiển thị danh sách sản phẩm (grid layout).
  - Bộ lọc sản phẩm (Filter) theo danh mục và giá.
  - Chức năng sắp xếp sản phẩm (Sort by: giá tăng dần, giảm dần, mới nhất).
- **Navbar & Breadcrumb**:
  - Điều hướng giữa các trang: Home, Shop, About, Contact.
  - Hiển thị đường dẫn hiện tại (breadcrumb).
- **Footer**:
  - Thông tin liên hệ, liên kết nhanh.
  - Newsletter đăng ký email.
- **Responsive**:
  - Hỗ trợ trên nhiều kích thước màn hình (PC, tablet, mobile).

## 🛠️ Công nghệ sử dụng
- **HTML5**  
- **CSS3**  
- **Bootstrap 5.3.3** (CDN)  
- **JavaScript (jQuery)**  
- **Google Fonts (Poppins)**  
- **Icons8** (icon user, search, like, cart, filter...)  

## 📂 Cấu trúc thư mục
├── home # Trang chủ
│ ├── images/ # Hình ảnh sản phẩm
│ ├── css/
│ │ └── style.css
│ ├── index.html/
├── shop # Trang cửa hang
│ ├──assets
│ │ └── css/
│ │ │ └── style.css
│ ├── js/
│ │ └── main.js # JavaScript xử lý sản phẩm & filter
│ └── icon/ # Icon (High Quality, Guarantee, Free Shipping...)
│ ├──index.html
│ ├──shop.html
└── README.md