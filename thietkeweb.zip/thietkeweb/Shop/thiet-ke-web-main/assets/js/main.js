$(document).ready(function() {

    // --- Form Validation (Bootstrap 5) ---
    const newsletterForm = $('#newsletterForm');
    if (newsletterForm.length) {
        newsletterForm.on('submit', function(event) {
            if (!this.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            $(this).addClass('was-validated');
        });
    }

    // --- Fade-in on Scroll ---
    const fadeInSections = $('.fade-in-section');
    if (fadeInSections.length > 0) {
        const observer = new IntersectionObserver(function(entries, observer) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    $(entry.target).addClass('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });

        fadeInSections.each(function() {
            observer.observe(this);
        });
    }

    // --- Call API & Display Products on Shop Page ---
    const productGrid = $('#product-grid');
    if (productGrid.length) {
        // Mock API data
        const mockProductData = [
            { id: 1, name: "Syltherine", description: "Stylish cafe chair", price: "2.500.000", old_price: "3.500.000", badge: "-30%", image: "d:/thietkeweb/Home/ảnh btl/image 1.png" },
            { id: 2, name: "Leviosa", description: "Stylish cafe chair", price: "2.500.000", old_price: null, badge: null, image: "d:/thietkeweb/Home/ảnh btl/Images (4).png" },
            { id: 3, name: "Lolito", description: "Luxury big sofa", price: "7.000.000", old_price: "14.000.000", badge: "-50%", image: "d:/thietkeweb/Home/ảnh btl/image 3.png" },
            { id: 4, name: "Respira", description: "Outdoor bar table and stool", price: "500.000", old_price: null, badge: "New", image: "d:/thietkeweb/Home/ảnh btl/image 4.png" },
            { id: 5, name: "Grifo", description: "Night lamp", price: "1.500.000", old_price: null, badge: null, image: "d:/thietkeweb/Home/ảnh btl/image 1.png" },
            { id: 6, name: "Muggo", description: "Small mug", price: "150.000", old_price: null, badge: "New", image: "d:/thietkeweb/Home/ảnh btl/Images (4).png" },
            { id: 7, name: "Pingky", description: "Cute bed set", price: "7.000.000", old_price: "14.000.000", badge: "-50%", image: "d:/thietkeweb/Home/ảnh btl/image 3.png" },
            { id: 8, name: "Potty", description: "Minimalist flower pot", price: "500.000", old_price: null, badge: null, image: "d:/thietkeweb/Home/ảnh btl/image 4.png" },
            { id: 9, name: "Syltherine", description: "Stylish cafe chair", price: "2.500.000", old_price: "3.500.000", badge: "-30%", image: "d:/thietkeweb/Home/ảnh btl/image 1.png" },
            { id: 10, name: "Leviosa", description: "Stylish cafe chair", price: "2.500.000", old_price: null, badge: null, image: "d:/thietkeweb/Home/ảnh btl/Images (4).png" },
            { id: 11, name: "Lolito", description: "Luxury big sofa", price: "7.000.000", old_price: "14.000.000", badge: "-50%", image: "d:/thietkeweb/Home/ảnh btl/image 3.png" },
            { id: 12, name: "Respira", description: "Outdoor bar table and stool", price: "500.000", old_price: null, badge: "New", image: "d:/thietkeweb/Home/ảnh btl/image 4.png" },
        ];
        
        // Simulate AJAX call with a 1-second delay
        setTimeout(function() {
            productGrid.empty(); // Clear spinner

            $.each(mockProductData, function(index, product) {
                let badgeHtml = '';
                if (product.badge) {
                    let badgeClass = product.badge.startsWith('-') ? '' : 'new';
                    badgeHtml = `<div class="product-badge ${badgeClass}">${product.badge}</div>`;
                }

                let oldPriceHtml = '';
                if (product.old_price) {
                    oldPriceHtml = `<span class="old-price">Rp ${product.old_price}</span>`;
                }

                const productCard = `
                    <div class="col-md-6 col-lg-3">
                        <div class="card product-card">
                            <div class="product-card-img">
                                <img src="${product.image}" alt="${product.name}">
                                ${badgeHtml}
                                <div class="product-overlay">
                                    <button class="btn btn-add-to-cart">Add to cart</button>
                                    <div class="action-links">
                                        <a href="#"><img src="https://img.icons8.com/ios-glyphs/16/000000/share--v1.png"/> Share</a>
                                        <a href="#"><img src="https://img.icons8.com/material-outlined/16/000000/sorting-arrows-horizontal.png"/> Compare</a>
                                        <a href="#"><img src="https://img.icons8.com/material-outlined/16/000000/like.png"/> Like</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">${product.name}</h5>
                                <p class="card-text">${product.description}</p>
                                <div class="product-price">
                                    <span>Rp ${product.price}</span>
                                    ${oldPriceHtml}
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                productGrid.append(productCard);
            });
        }, 1000); 
    }
});