

function updateCartTotal() {
    let cartItems = document.querySelectorAll(".cart-item"); 
    let total = 0;

    for (let i = 0; i < cartItems.length; i++) {
        let priceElement = cartItems[i].querySelector(".item-price");
        let qtyElement = cartItems[i].querySelector(".qty-input");
        let subtotalElement = cartItems[i].querySelector(".item-subtotal");

        let price = parseFloat(priceElement.innerText.replace("Rs.", "").replace(",", ""));
        let qty = parseInt(qtyElement.value);

        if (isNaN(qty) || qty < 1) {
            qty = 1; 
            qtyElement.value = 1;
        }

        let subtotal = price * qty;
        subtotalElement.innerText = "Rs. " + subtotal.toLocaleString();

        total = total + subtotal;
    }

    document.getElementById("cart-total").innerText = "Rs. " + total.toLocaleString();
}


let qtyInputs = document.querySelectorAll(".qty-input");
for (let i = 0; i < qtyInputs.length; i++) {
    qtyInputs[i].addEventListener("change", updateCartTotal);
}


let removeBtns = document.querySelectorAll(".remove-btn");
for (let i = 0; i < removeBtns.length; i++) {
    removeBtns[i].addEventListener("click", function () {
        this.parentElement.parentElement.remove();
        updateCartTotal();
    });
}


updateCartTotal();
